﻿#include "management.hpp"
#include <algorithm>


Management::Management()
{
	string filename = "dit_uoi_course.txt";
	fstream fs;
	fs.open(filename, ios::in);
	if (!fs.is_open())
	{
		cerr << "File " << filename << " does not exist" << endl;
		return;
	}
	string line,word;
	bool first_line = true;
	vector <string> data;
	while (getline(fs, line))
	{
		if (first_line)
		{
			first_line = false;
			continue;
		}
		data.clear();
		stringstream ss(line);
		while (getline(ss, word, ','))
		{
			data.push_back(word);
		}
		this->courses.push_back(Course(data[0],stoi(data[1]),data[2],stoi(data[3])));
	}
	fs.close();
}

Management::~Management() {}

void Management::insert_student()
{
	system("cls");
	string id,name;
	int semester, credits;
	cout << "Δώσε AM φοιτητή:";
	cin >> id;
	cin.ignore();
	cout << "Δώσε όνομα φοιτητή:";
	getline(cin, name);
	cout << "Δώσε Εξάμηνο φοιτητή:";
	cin >> semester;
	cout << "Δώσε Δ. Μονάδες φοιτητή:";
	cin >> credits;
	this->students.push_back(Student(id, name, semester, credits));
	this->display_students();
	system("pause");
	
}

void Management::display_students()
{
	std::cout << "=== ΦΟΙΤΗΤΕΣ ===" << std::endl;
	for (auto& student : this->students)
	{
		std::cout << student << std::endl;
	}
}