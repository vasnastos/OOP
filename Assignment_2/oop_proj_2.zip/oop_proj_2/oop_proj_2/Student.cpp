#include "student.hpp"

Student::Student(string sid, string sfullname, int ssemester, int scredits) :id(sid), fullname(sfullname), semester(ssemester), credits(scredits) {}


void Student::add_course(Course& c)
{
    this->courses.push_back(c);
}

ostream& operator<<(ostream& os, const Student& s)
{
    return os << s.id << " " << s.fullname << " " << s.semester << " " << s.credits;
}