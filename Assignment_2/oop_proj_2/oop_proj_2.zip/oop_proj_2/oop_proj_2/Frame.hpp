#include <wx/wx.h>

class Frame :public wxFrame
{

};