#include "racing.hpp"

int main()
{
    
    return EXIT_SUCCESS;
}